package com.xiteb.eventcalendar.db
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.xiteb.eventcalendar.model.EventModel
class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "events_database"
        private const val DATABASE_VERSION = 2 // Update the version when changing the schema

        private const val TABLE_NAME = "events"
        private const val COLUMN_ID = "id"
        private const val COLUMN_TITLE = "title"
        private const val COLUMN_NOTE = "note"
        private const val COLUMN_DATE = "date"
        private const val COLUMN_START_TIME = "start_time"
        private const val COLUMN_END_TIME = "end_time"
        private const val COLUMN_NOTI_BEFORE = "notiBefore" // New column
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableQuery = ("CREATE TABLE $TABLE_NAME ("
                + "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "$COLUMN_TITLE TEXT,"
                + "$COLUMN_NOTE TEXT,"
                + "$COLUMN_DATE TEXT,"
                + "$COLUMN_START_TIME TEXT,"
                + "$COLUMN_END_TIME TEXT,"
                + "$COLUMN_NOTI_BEFORE TEXT)") // Add the new column

        db.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertEvent(event: EventModel): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_TITLE, event.title)
        values.put(COLUMN_NOTE, event.note)
        values.put(COLUMN_DATE, event.date)
        values.put(COLUMN_START_TIME, event.sTime)
        values.put(COLUMN_END_TIME, event.eTime)
        values.put(COLUMN_NOTI_BEFORE, event.notiBefore) // Insert the new column value

        val id = db.insert(TABLE_NAME, null, values)
        db.close()
        return id
    }

    @SuppressLint("Range")
    fun getEvent(id: Long): EventModel? {
        val db = this.readableDatabase
        val cursor: Cursor = db.query(TABLE_NAME, null, "$COLUMN_ID=?",
            arrayOf(id.toString()), null, null, null, null)

        return if (cursor.moveToFirst()) {
            val event = EventModel(
                cursor.getString(cursor.getColumnIndex(COLUMN_ID)),
                cursor.getString(cursor.getColumnIndex(COLUMN_TITLE)),
                cursor.getString(cursor.getColumnIndex(COLUMN_NOTE)),
                cursor.getString(cursor.getColumnIndex(COLUMN_DATE)),
                cursor.getString(cursor.getColumnIndex(COLUMN_START_TIME)),
                cursor.getString(cursor.getColumnIndex(COLUMN_END_TIME)),
                cursor.getString(cursor.getColumnIndex(COLUMN_NOTI_BEFORE)) // Retrieve the new column
            )
            cursor.close()
            event
        } else {
            cursor.close()
            null
        }
    }

    @SuppressLint("Range")
    fun getAllEvents(): ArrayList<EventModel> {
        val eventsList = ArrayList<EventModel>()
        val db = this.readableDatabase
        val cursor: Cursor = db.query(TABLE_NAME, null, null, null, null, null, null)

        if (cursor.moveToFirst()) {
            do {
                val event = EventModel(
                    cursor.getString(cursor.getColumnIndex(COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_TITLE)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_NOTE)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_DATE)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_START_TIME)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_END_TIME)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_NOTI_BEFORE)) // Retrieve the new column
                )
                eventsList.add(event)
            } while (cursor.moveToNext())
        }

        cursor.close()
        return eventsList
    }

    @SuppressLint("Range")
    fun getEventsByDate(date: String): ArrayList<EventModel> {
        val eventsList = ArrayList<EventModel>()
        val db = this.readableDatabase
        val cursor: Cursor = db.query(
            TABLE_NAME,
            null,
            "$COLUMN_DATE =?",
            arrayOf(date),
            null,
            null,
            "$COLUMN_START_TIME" // Order by start time
        )

        if (cursor.moveToFirst()) {
            do {
                val event = EventModel(
                    cursor.getString(cursor.getColumnIndex(COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_TITLE)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_NOTE)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_DATE)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_START_TIME)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_END_TIME)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_NOTI_BEFORE)) // Retrieve the new column
                )
                eventsList.add(event)
            } while (cursor.moveToNext())
        }

        cursor.close()
        return eventsList
    }

    fun updateEvent(event: EventModel): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_TITLE, event.title)
        values.put(COLUMN_NOTE, event.note)
        values.put(COLUMN_DATE, event.date)
        values.put(COLUMN_START_TIME, event.sTime)
        values.put(COLUMN_END_TIME, event.eTime)
        values.put(COLUMN_NOTI_BEFORE, event.notiBefore) // Update the new column value

        return db.update(TABLE_NAME, values, "$COLUMN_ID=?", arrayOf(event.id))
    }

    fun deleteEvent(id: Long): Int {
        val db = this.writableDatabase
        return db.delete(TABLE_NAME, "$COLUMN_ID=?", arrayOf(id.toString()))
    }
}
