package com.xiteb.eventcalendar.controller

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class DateTimeController {
    companion object{
        fun openCalendar(context: Context, onDateSelected: (String) -> Unit) {
            val calendar = Calendar.getInstance()
            val initialYear = calendar.get(Calendar.YEAR)
            val initialMonth = calendar.get(Calendar.MONTH)
            val initialDay = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(
                context,
                { _, year, month, day ->
                    val selectedDate = Calendar.getInstance()
                    selectedDate.set(year, month, day)
                    val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
                    val formattedDate = dateFormat.format(selectedDate.time)
                    onDateSelected(formattedDate)
                },
                initialYear,
                initialMonth,
                initialDay
            )

            datePickerDialog.show()
        }

        fun openTimePicker(context: Context, onTimeSelected: (String) -> Unit) {
            val calendar = Calendar.getInstance()
            val initialHour = calendar.get(Calendar.HOUR_OF_DAY)
            val initialMinute = calendar.get(Calendar.MINUTE)
            val is24HourFormat = false // Set to true for 24-hour format, false for AM/PM format

            val timePickerDialog = TimePickerDialog(
                context,
                { _, hourOfDay, minute ->
                    val selectedTime = Calendar.getInstance()
                    selectedTime.set(Calendar.HOUR_OF_DAY, hourOfDay)
                    selectedTime.set(Calendar.MINUTE, minute)

                    val dateFormat = SimpleDateFormat("hh:mma", Locale.getDefault())
                    val formattedTime = dateFormat.format(selectedTime.time)
                    onTimeSelected(formattedTime)
                },
                initialHour,
                initialMinute,
                is24HourFormat
            )

            timePickerDialog.show()
        }

        fun convertDateTimeToLong(dateString: String, timeString: String): Long {
            val dateTimeString = "$dateString $timeString"
            val format = SimpleDateFormat("dd.MM.yyyy hh:mma", Locale.getDefault())

            return try {
                val date = format.parse(dateTimeString)
                date?.time ?: -1L // Return -1L if parsing fails
            } catch (e: Exception) {
                -1L
            }
        }


    }

}