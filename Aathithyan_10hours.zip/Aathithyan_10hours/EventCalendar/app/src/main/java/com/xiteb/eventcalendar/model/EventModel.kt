package com.xiteb.eventcalendar.model

data class EventModel(
    val id: String?,
    val title: String?,
    val note: String?,
    val date: String?,
    val sTime: String?,
    val eTime: String?,
    val notiBefore: String?,
)