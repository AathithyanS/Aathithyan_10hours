package com.xiteb.eventcalendar

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.Dialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.xiteb.eventcalendar.adapter.EventRvAdapter
import com.xiteb.eventcalendar.controller.DateTimeController
import com.xiteb.eventcalendar.controller.NotificationController
import com.xiteb.eventcalendar.databinding.ActivityMainBinding
import com.xiteb.eventcalendar.db.DatabaseHelper
import com.xiteb.eventcalendar.model.EventModel
import com.xiteb.eventcalendar.receiver.EventReceiver
import com.xiteb.eventcalendar.utils.HolidayCalendarDialog
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding;
    var isFull = false
    lateinit var dbHelper:DatabaseHelper;
    lateinit var toDate: String
    lateinit var selectedDate: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DatabaseHelper(this)

        binding.addEventBtn.setOnClickListener {
            openAddEventDialog()
        }


        binding.adjIv.setOnClickListener {
            adjustScreen()
        }


        updateCurrDate()
        selectedDate = toDate
        setEventsRv()

        binding.calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            selectedDate = String.format(Locale.getDefault(), "%02d.%02d.%d", dayOfMonth, month + 1, year)
            binding.sDateTv.text = "($selectedDate) Events"
            setEventsRv()
        }

        binding.hollidayBtn.setOnClickListener{
            showHolidays()
        }



    }

    private fun showHolidays() {
        HolidayCalendarDialog(this).showHolidaysDialog()
    }

    fun setEventsRv() {
        val events = dbHelper.getEventsByDate(selectedDate)
        binding.eventRv.layoutManager = LinearLayoutManager(this)
        val eventAdapter = EventRvAdapter(this, events)
        binding.eventRv.adapter = eventAdapter
    }

    private fun updateCurrDate() {
        val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val currDate: Long = binding.calendarView.date
        val date  = dateFormat.format(currDate)
        toDate = date;
        binding.sDateTv.text = "($date) Events"
    }

    private fun adjustScreen() {
        if (isFull == false) {
            binding.adjIv.setImageResource(R.drawable.ic_down)
            isFull = true
            binding.calendarView.visibility = View.GONE
        }else{
            binding.calendarView.visibility = View.VISIBLE
            binding.adjIv.setImageResource(R.drawable.ic_up)
            isFull = false
        }
    }

    private fun openAddEventDialog() {
        val dialog = Dialog(this)
        val layoutInflater = LayoutInflater.from(this)
        val view = layoutInflater.inflate(R.layout.add_event_dialog, null)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        dialog.setContentView(view)
        dialog.show()

        val title = view.findViewById<EditText>(R.id.aTitleTv)
        val date = view.findViewById<EditText>(R.id.aDateTv)
        val sTime = view.findViewById<EditText>(R.id.aSTTv)
        val eTime = view.findViewById<EditText>(R.id.aETv)
        val note = view.findViewById<EditText>(R.id.aNTv)
        val noti = view.findViewById<EditText>(R.id.notiBeTv)
        val addBtn = view.findViewById<Button>(R.id.addBtn)

        date.setOnClickListener{
            DateTimeController.openCalendar(this) { selectedDate ->
                date.setText(selectedDate)
            }
        }

        sTime.setOnClickListener {
            DateTimeController.openTimePicker(this) { selectedTime ->
                sTime.setText(selectedTime)
            }
        }

        eTime.setOnClickListener {
            DateTimeController.openTimePicker(this) { selectedTime ->
                eTime.setText(selectedTime)
            }
        }

        noti.setOnClickListener {
            showNotiPopup(it, noti)
        }

        addBtn.setOnClickListener{
            val titleText = title.text.toString().trim()
            val dateText = date.text.toString().trim()
            val sTimeText = sTime.text.toString().trim()
            val eTimeText = eTime.text.toString().trim()
            val noteText = note.text.toString().trim()
            val notiText = noti.text.toString().trim()

            if (titleText.isEmpty() || dateText.isEmpty() || sTimeText.isEmpty() || eTimeText.isEmpty() || noteText.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                val eventModel = EventModel(
                    id = null, // You may generate or assign an ID here
                    title = titleText,
                    note = noteText,
                    date = dateText,
                    sTime = sTimeText,
                    eTime = eTimeText,
                    notiBefore = notiText
                )
                val id = dbHelper.insertEvent(eventModel)
                NotificationController.setNotificationAlarm(titleText, noteText, dateText, sTimeText, id, notiText,this)
                setEventsRv()
                Toast.makeText(this, "Event added successfully", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }

        }

    }

    fun openEditEventDialog(event: EventModel) {
        val dialog = Dialog(this)
        val layoutInflater = LayoutInflater.from(this)
        val view = layoutInflater.inflate(R.layout.edit_event_dialog, null)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        dialog.setContentView(view)
        dialog.show()

        val title = view.findViewById<EditText>(R.id.eTitleTv)
        val date = view.findViewById<EditText>(R.id.eDateTv)
        val sTime = view.findViewById<EditText>(R.id.eSTTv)
        val eTime = view.findViewById<EditText>(R.id.eETv)
        val note = view.findViewById<EditText>(R.id.eNTv)
        val noti = view.findViewById<EditText>(R.id.eNotiBeTv)
        val updateBtn = view.findViewById<Button>(R.id.updateBtn)

        title.setText(event.title)
        date.setText(event.date)
        sTime.setText(event.sTime)
        eTime.setText(event.eTime)
        note.setText(event.note)
        noti.setText(event.notiBefore)

        date.setOnClickListener{
            DateTimeController.openCalendar(this) { selectedDate ->
                date.setText(selectedDate)
            }
        }

        sTime.setOnClickListener {
            DateTimeController.openTimePicker(this) { selectedTime ->
                sTime.setText(selectedTime)
            }
        }

        eTime.setOnClickListener {
            DateTimeController.openTimePicker(this) { selectedTime ->
                eTime.setText(selectedTime)
            }
        }

        noti.setOnClickListener {
            showNotiPopup(it, noti)
        }

        updateBtn.setOnClickListener{
            val titleText = title.text.toString().trim()
            val dateText = date.text.toString().trim()
            val sTimeText = sTime.text.toString().trim()
            val eTimeText = eTime.text.toString().trim()
            val noteText = note.text.toString().trim()
            val notiText = noti.text.toString().trim()

            if (titleText.isEmpty() || dateText.isEmpty() || sTimeText.isEmpty() || eTimeText.isEmpty() || noteText.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                val eventModel = EventModel(
                    id = event.id,
                    title = titleText,
                    note = noteText,
                    date = dateText,
                    sTime = sTimeText,
                    eTime = eTimeText,
                    notiBefore = notiText
                )
                dbHelper.updateEvent(eventModel)
                NotificationController.cancelNotificationAlarm(event.id!!.toLong(), this)
                NotificationController.setNotificationAlarm(titleText, noteText, dateText, sTimeText, event.id!!.toLong(), notiText,this)
                setEventsRv()
                Toast.makeText(this, "Event updated successfully", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }

        }
    }

    private fun showNotiPopup(view: View, editText: EditText) {
        val popupMenu = PopupMenu(this, view)
        val menuInflater = popupMenu.menuInflater
        menuInflater.inflate(R.menu.noti_before_selection, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener { menuItem: MenuItem ->
            editText.setText("${menuItem.title}")
            when (menuItem.itemId) {
                R.id.be0 -> {
                    true
                }
                R.id.be15m -> {
                    true
                }
                R.id.be1h -> {
                    true
                }
                R.id.be1d -> {
                    true
                }
                else -> false
            }
        }

        // Show the popup menu
        popupMenu.show()
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        if(isFull){
            adjustScreen()
        }else{
            finish()
        }
    }
}