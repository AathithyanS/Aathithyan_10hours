package com.xiteb.eventcalendar.adapter

import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.xiteb.eventcalendar.MainActivity
import com.xiteb.eventcalendar.R
import com.xiteb.eventcalendar.controller.NotificationController
import com.xiteb.eventcalendar.model.EventModel

class EventRvAdapter(val context: MainActivity, val events: ArrayList<EventModel>): RecyclerView.Adapter<EventRvAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventRvAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.event_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: EventRvAdapter.ViewHolder, position: Int) {
        val event = events.get(position)
        holder.eSTimeTv.text = "Start Time: ${event.sTime}"
        holder.eETimeTv.text = "End Time: ${event.eTime}"
        holder.eNoteTv.text = event.note
        holder.eTitleTv.text = event.title
        holder.moreIv.setOnClickListener {
            showPopupMenu(it, event)
        }
    }

    override fun getItemCount(): Int {
        return events.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)  {
        val moreIv: ImageView = itemView.findViewById(R.id.moreIv)
        val eSTimeTv: TextView = itemView.findViewById(R.id.eSTimeTv)
        val eETimeTv: TextView = itemView.findViewById(R.id.eETimeTv)
        val eTitleTv: TextView = itemView.findViewById(R.id.eTitleTv)
        val eNoteTv: TextView = itemView.findViewById(R.id.eNoteTv)
    }

    private fun showPopupMenu(view: View, event: EventModel) {
        val popupMenu = PopupMenu(context, view)
        val menuInflater = popupMenu.menuInflater
        menuInflater.inflate(R.menu.ud_selection, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener { menuItem: MenuItem ->
            when (menuItem.itemId) {
                R.id.edit -> {
                    context.openEditEventDialog(event)
                    true
                }
                R.id.delete -> {
                    if (event.id != null) {
                        context.dbHelper.deleteEvent(event.id.toLong())
                        NotificationController.cancelNotificationAlarm(event.id.toLong(), context)
                        context.setEventsRv()
                    }
                    true
                }
                else -> false
            }
        }

        // Show the popup menu
        popupMenu.show()
    }
}