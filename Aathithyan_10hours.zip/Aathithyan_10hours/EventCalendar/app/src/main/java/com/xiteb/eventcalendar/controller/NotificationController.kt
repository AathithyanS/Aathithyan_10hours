package com.xiteb.eventcalendar.controller

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.xiteb.eventcalendar.receiver.EventReceiver
import java.text.ParseException
import java.util.Locale

class NotificationController {
    companion object{

        fun setNotificationAlarm(
            title: String,
            description: String,
            date: String,
            time: String,
            notiId: Long,
            plan: String,
            context: Context
        ) {
            val alarmManager = context.getSystemService(AppCompatActivity.ALARM_SERVICE) as AlarmManager
            try {
                val dateTimeInMillis = DateTimeController.convertDateTimeToLong(date, time)
                val currentTimeMillis = System.currentTimeMillis()

                if (dateTimeInMillis > currentTimeMillis) {
                    val intent = Intent(context, EventReceiver::class.java)
                    intent.putExtra("title", title)
                    intent.putExtra("description", description)
                    val pendingIntent = PendingIntent.getBroadcast(context, notiId.toInt(), intent, PendingIntent.FLAG_IMMUTABLE)

                    val notificationTime = calculateNotificationTime(dateTimeInMillis, plan)

                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent)
                } else {
                    Toast.makeText(context, "Selected time is in the past", Toast.LENGTH_SHORT).show()
                }

            } catch (e: ParseException) {
                Toast.makeText(context, "Error parsing date or time", Toast.LENGTH_SHORT).show()
            }
        }

        private fun calculateNotificationTime(dateTimeInMillis: Long, plan: String): Long {
            return when (plan.toLowerCase(Locale.getDefault())) {
                "same starting time" -> dateTimeInMillis
                "15 minutes before" -> dateTimeInMillis - 15 * 60 * 1000 // 15 minutes in milliseconds
                "1 hour before" -> dateTimeInMillis - 60 * 60 * 1000 // 1 hour in milliseconds
                "1 day before" -> dateTimeInMillis - 24 * 60 * 60 * 1000 // 1 day in milliseconds
                else -> throw IllegalArgumentException("Invalid notification plan: $plan")
            }
        }

        fun cancelNotificationAlarm(notiId: Long, context: Context) {
            val alarmManager = context.getSystemService(AppCompatActivity.ALARM_SERVICE) as AlarmManager

            val intent = Intent(context, EventReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(context, notiId.toInt(), intent, PendingIntent.FLAG_IMMUTABLE)
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.cancel(notiId.toInt())
        }


    }
}