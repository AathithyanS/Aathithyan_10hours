package com.xiteb.eventcalendar.utils

import android.R
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.graphics.Color
import com.applandeo.materialcalendarview.CalendarView
import com.applandeo.materialcalendarview.EventDay
import com.xiteb.eventcalendar.MainActivity
import java.util.Calendar


class HolidayCalendarDialog(private val context: MainActivity) {

    @SuppressLint("SuspiciousIndentation")
    fun showHolidaysDialog() {
        val dialogBuilder = AlertDialog.Builder(context)
        val inflater = context.layoutInflater
        val dialogView = inflater.inflate(com.xiteb.eventcalendar.R.layout.dialog_holiday_calendar, null)
        dialogBuilder.setView(dialogView)

        val calendarView = dialogView.findViewById<CalendarView>(com.xiteb.eventcalendar.R.id.calendarHoliView)
        val calendar1 = Calendar.getInstance()
            calendar1.set(2024, Calendar.MARCH, 4)
        val calendar2 = Calendar.getInstance()
            calendar2.set(2024, Calendar.MARCH, 8)
        val calendar3 = Calendar.getInstance()
            calendar3.set(2024, Calendar.APRIL, 30)

        val events: ArrayList<EventDay> = ArrayList()
        events.add(EventDay(calendar1, com.xiteb.eventcalendar.R.drawable.event_back, Color.parseColor("#228B22")))
        events.add(EventDay(calendar2, com.xiteb.eventcalendar.R.drawable.event_back, Color.parseColor("#228B22")))
        events.add(EventDay(calendar3, com.xiteb.eventcalendar.R.drawable.event_back, Color.parseColor("#228B22")))

        calendarView.setEvents(events);

        val alertDialog = dialogBuilder.create()
        alertDialog.setTitle("Holiday Calendar( Test holidays not real marked in purple colors )")
        alertDialog.setCancelable(true)
        alertDialog.show()
    }

}
